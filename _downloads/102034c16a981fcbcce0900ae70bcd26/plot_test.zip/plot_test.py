"""
Test Example
============
"""
import matplotlib.pyplot as plt

plt.plot([1, 2], [1, 2])

plt.show()
